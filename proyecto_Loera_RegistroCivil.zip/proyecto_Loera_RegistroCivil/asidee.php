<aside>
				<div class="widget">
					<h3>Tablas del Registro Civil</h3>
					<ul>
                        <li><a href="index.php">Inicio</a></li>
                        <li><a href="crud_empleado/empleado.php"> Empleado</a></li>
						<li><a href="acta.php">Bodas</a></li>
						<li><a href="acta.php">Acta de Nacimiento</a></li>
                        <li><a href="acta.php">Divorcios</a></li>
						
					</ul>
				</div>
			</aside>