<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <title>20 Noel Loera </title>
    
	<link rel="stylesheet" href="/proyecto_Loera_registrocivil/estilos.css">
</head>
<body>
	<header>
		<div class="wrapp">
			<div class="logo">
				<img src="/proyecto_Loera_registrocivil/img/logo.png"> 
			</div>
			<nav>
				<ul>
					<li><a href="/proyecto_Loera_registrocivil/index.php">Inicio</a></li>
					<li><a href="/proyecto_Loera_registrocivil/crud_empleado/empleado.php">Empleado</a></li>
					<li><a href="/proyecto_Loera_registrocivil/crud_bodas/bodas.php">Novio </a></li>
					<li><a href="/proyecto_Loera_registrocivil/crud_novia/bodas.php">Novia </a></li>
					<li><a href="/proyecto_Loera_registrocivil/crud_actas/bodas.php">Acta de Nacimiento </a></li>

				</ul>
			</nav>
		</div>
	</header>